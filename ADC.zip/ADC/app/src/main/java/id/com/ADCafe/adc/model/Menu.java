package id.com.ADCafe.adc.model;

public class Menu{

    public String kodeMenu;
    public String namaMenu;
    public Integer harga;

    public Menu(){}

    public Menu(String kodeMenu, String namaMenu, Integer harga) {
        this.kodeMenu = kodeMenu;
        this.namaMenu = namaMenu;
        this.harga = harga;
    }
}
