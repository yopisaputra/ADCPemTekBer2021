package id.com.ADCafe.adc.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.zip.Inflater;

import id.com.ADCafe.adc.R;
import id.com.ADCafe.adc.model.Menu;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {

    ArrayList<Menu> listData = new ArrayList<>();

    public class MenuViewHolder extends RecyclerView.ViewHolder{

        TextView textKodeMenu,textNamaMenu,textHarga;

        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);

            textKodeMenu = itemView.findViewById(R.id.textKodeMenu);
            textNamaMenu = itemView.findViewById(R.id.textNamaMenu);
            textHarga = itemView.findViewById(R.id.textHarga);
        }
    }

    public void setListData(ArrayList<Menu> listData) {
        this.listData = listData;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_menu, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {

        Menu menu = listData.get(position);
        holder.textKodeMenu.setText(menu.kodeMenu);
        holder.textNamaMenu.setText(menu.namaMenu);
        holder.textHarga.setText(menu.harga.toString());

    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

}
