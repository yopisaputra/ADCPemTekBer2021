package id.com.ADCafe.adc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

import id.com.ADCafe.adc.adapter.MenuAdapter;
import id.com.ADCafe.adc.model.Menu;

public class DaftarMenuActivity extends AppCompatActivity {

    RecyclerView rvListMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_menu);

        MenuAdapter adapter = new MenuAdapter();
        adapter.setListData(getMenu());

        rvListMenu = findViewById(R.id.rvListMenu);
        rvListMenu.setAdapter(adapter);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rvListMenu.setLayoutManager(layoutManager);
    }

    public ArrayList<Menu> getMenu(){
        ArrayList<Menu> listMenu = new ArrayList<Menu>();

        listMenu.add(new Menu(
                "food1",
                "ABC",
                10000));
        listMenu.add(new Menu(
                "food2",
                "VBN",
                10000));
        listMenu.add(new Menu(
                "food3",
                "ALF",
                10000));
        listMenu.add(new Menu(
                "drink1",
                "FHG",
                10000));
        listMenu.add(new Menu(
                "drink2",
                "DFR",
                10000));
        listMenu.add(new Menu(
                "drink3",
                "BCE",
                10000));
        listMenu.add(new Menu(
                "desserts1",
                "FGK",
                5000));
        listMenu.add(new Menu(
                "desserts2",
                "FASK",
                5000));
        listMenu.add(new Menu(
                "snack1",
                "KHD",
                5000));
        listMenu.add(new Menu(
                "snack2",
                "YSP",
                5000));


        return listMenu;

    }
}